
// client/src/Cart.js

import React from 'react';

function Cart() {
  return (
    <div>
      <h2>Shopping Cart</h2>
      {/* Cart functionality can be implemented here */}
    </div>
  );
}

export default Cart;
